# PRT661 WP4 — Individual Code Submission

**Sudip Lamichhane** · S388085 · Data Acquisition & Automation
Work package: WP4 — Operational portal, automation and deployment
Build: portal v3.0.0 · pipeline v4.0.0 · model evidence wp4-2026-09-29
(run `EnergyForecast_Run_20260929_145931`)

---

## 1. Scope of this submission

Making the system run without a person: live acquisition, the two scheduled jobs, the persistent worker, first-start bootstrap, the AEMO official feed, and the deployment architecture.

This archive contains **only the files owned by this student**, at their original
repository paths. It is an extract from the integrated portal, not a standalone
application: the modules import from teammates' modules that are deliberately not
included here. Section 4 lists those dependencies. The complete runnable system is
the group submission.

> Ownership follows the role titles declared in the portal (`app/app.py`, `TEAM`) and
> the continuity of ownership from WP2 and WP3. It is **not** derived from commit
> history: the supplied repository contained no commits. Commit links must be added
> before submission.

---

## 2. Files owned

| File | Lines | What it does |
|---|---|---|
| `pipeline/acquisition_live.py` | 423 | Live acquisition. Refreshes the current demand tail, retrieves a weather forecast vintage keyed by forecast origin, and stores AEMO's published operational-demand forecast where available. |
| `pipeline/operational_job.py` | 42 | Fast 30-minute cycle: refresh inputs, store the next-interval forecast users see, score earlier ones whose actuals have arrived. |
| `pipeline/hourly_job.py` | 43 | Hourly job: full current-month-plus-three-month outlook refresh and the broader verification pass. |
| `pipeline/railway_worker.py` | 264 | Persistent scheduler. Expands the one-time asset archive when the volume is empty, verifies the approved six-region production mapping, initialises the database, seeds history, records provenance, runs startup jobs, then holds minutes 05/35 and hourly minute 15. |
| `pipeline/bootstrap.py` | 215 | First-deployment load. |
| `pipeline/aemo_official.py` | 92 | AEMO official operational-demand forecast retrieval. |
| `tools/build_worker_assets.py` | 191 | Packages only the six selected bundles, portable pointers, the Stage 2 runtime snapshot and a provenance manifest. Deliberately excludes the raw archive, the local database and non-production bundles. |
| `DEPLOYMENT_RAILWAY.md` | 158 | Two-service Railway deployment sequence and full environment contract. |
| `infra/aws_deployment.md` | 54 | AWS blueprint: App Runner / ECS, RDS, S3, Secrets Manager, EventBridge scheduling. |
| **Total** | **1,482** | |

---

## 3. Tests owned

None. This workstream is covered indirectly: the worker's startup mapping verification is exercised through the production-resolver suite, and the scheduled jobs are verified by their run records in `pipeline_runs` rather than by unit tests. **Adding direct tests for the scheduled jobs is a recommended next step.**

---

## 4. Dependencies on other team members

These modules are imported by the files above and are **not** in this archive.

| Member | Module / contract | Why it is needed |
|---|---|---|
| Ashish | `pipeline/model_evidence.py` | the worker verifies the approved production mapping at startup against his resolver. |
| Suraj | `pipeline/database.py` | init_db() is the worker's first call, and every job writes its status to his pipeline_runs table. |
| Bishal | `app/app.py` | the freshness guard is the user-visible half of this scheduling work: a missed cycle is announced rather than hidden. |

---

## 5. How to run

From the **complete** project root, with `pip install -r requirements.txt` already done:

```bash
python -m pipeline.bootstrap           # first deployment only
python -m pipeline.operational_job     # 30-minute cycle
python -m pipeline.hourly_job          # hourly outlook refresh
python -m pipeline.railway_worker      # persistent scheduler
python tools/build_worker_assets.py    # build the one-time asset archive
```

Running these commands from inside this extract alone will fail on the missing
imports listed in Section 4. That is expected.

---

## 6. Claims this code supports

- Three scheduled jobs: operational at minutes 05 and 35, hourly outlook at minute 15, monthly retrain.
- Six-step worker startup sequence, each step logged.
- Every job writes status and detail to the pipeline_runs table; a failed cycle leaves a record rather than silence.
- Two deployment targets documented: Railway two-service (primary) and an AWS blueprint.
- NOT IMPLEMENTED: AEMO correction handling. No correction listener, provisional state or recalculation flag exists. Recorded as an open Assessment 1 Section 6 commitment.
- Docker build, PostgreSQL execution and browser checks are deferred to the deployment host.

---

## 7. Evidence trail

| Artefact | Where |
|---|---|
| Individual contribution document | `WP4_Sudip_Lamichhane.docx` |
| Consolidated work-package report | `PRT661_WP4_Portal_Contribution_and_Progress_Report.docx` |
| Pre-release audit (11 production-correctness findings) | `AUDIT_V3.md` |
| Release change log | `CHANGELOG_V3.md` |
| Test record (go / no-go gates, and what was not run) | `TEST_REPORT_V3.md` |
| Model evidence pack (27 files, SHA-256 manifest) | `data/model_evidence/current/` |
| Running portal | 9 screenshots, 2 October 2026 |
| Commit history | **[INSERT GITHUB COMMIT / PULL REQUEST LINKS]** |

---

*Generated for PRT661 Assessment 2, Group Dan6 / Group 2. Every line count and claim
above is read from the supplied source; none is estimated.*
