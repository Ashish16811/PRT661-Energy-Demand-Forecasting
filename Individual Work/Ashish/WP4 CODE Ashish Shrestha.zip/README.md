# PRT661 WP4 — Individual Code Submission

**Ashish Shrestha** · S388084 · Forecasting & Project Lead
Work package: WP4 — Operational portal, automation and deployment
Build: portal v3.0.0 · pipeline v4.0.0 · model evidence wp4-2026-09-29
(run `EnergyForecast_Run_20260929_145931`)

---

## 1. Scope of this submission

Model resolution, bundle validation, live inference and monthly retraining — deciding which model each region is served and executing it safely on a schedule.

This archive contains **only the files owned by this student**, at their original
repository paths. It is an extract from the integrated portal, not a standalone
application: the modules import from teammates' modules that are deliberately not
included here. Section 4 lists those dependencies. The complete runnable system is
the group submission.

> Ownership follows the role titles declared in the portal (`app/app.py`, `TEAM`) and
> the continuity of ownership from WP2 and WP3. It is **not** derived from commit
> history: the supplied repository contained no commits. Commit links must be added
> before submission.

---

## 2. Files owned

| File | Lines | What it does |
|---|---|---|
| `pipeline/model_evidence.py` | 445 | Production resolver. A model is served only if it is selected by the evidence pack, is on the deployment allow-list, and loads as a structurally valid portal bundle. Also exposes the `status` and `validate-bundles` commands. |
| `pipeline/live_inference.py` | 566 | Live forecasting. Produces the next-interval forecast and the recursive four-month outlook; portable bundle loading with Stage 2 root rebasing and per-run production resolution. |
| `pipeline/model_training.py` | 227 | Model training with targeted arguments (--region, --model, --reuse-stage2). Research models are refused by name. |
| `pipeline/monthly_retrain.py` | 68 | Monthly retrain of already-approved algorithms with a holdout deployment gate. Does not repeat Stage 3 model selection. |
| `pipeline/repack_current_bundle.py` | 261 | Rewrites bundle pointers and Stage 2 roots into portable relative form. |
| `pipeline/feature_contract.py` | 66 | The authoritative feature contract: Feature Set A = 39 features, no weather; Feature Set B = A + 15 weather/context = 54. |
| **Total** | **1,633** | |

---

## 3. Tests owned

| Test file | Covers |
|---|---|
| `tests/test_production_resolver.py` | 12 tests — selection mapping, SA1 fallback, WA bundle, bundle-structure validation (a bare Stage 3 .joblib is refused), research models never served, legacy and relative path resolution. |
| `tests/test_training_cli.py` | 5 tests — targeted retraining arguments; research models refused. |
| `tests/test_feature_contract.py` | 4 tests — Set A exactly 39 with no weather; Set B exactly 54 and equal to the Stage 2 definitions. |

---

## 4. Dependencies on other team members

These modules are imported by the files above and are **not** in this archive.

| Member | Module / contract | Why it is needed |
|---|---|---|
| Suraj | `pipeline/database.py, config.py` | inference writes forecasts into his schema and reads configuration through his lazy resolver. |
| Bishal | `pipeline/insights.py, tests/` | the tests assert the feature contract against Stage 2, and the insight layer renders the selection evidence. |
| Sudip | `pipeline/railway_worker.py` | verifies the approved production mapping at startup, giving the resolver a second independent check. |

---

## 5. How to run

From the **complete** project root, with `pip install -r requirements.txt` already done:

```bash
python -m pipeline.model_evidence status
python -m pipeline.model_evidence validate-bundles
python -m pipeline.monthly_retrain --region SA1 --model RandomForest_B
python -m pytest tests/test_production_resolver.py tests/test_training_cli.py tests/test_feature_contract.py -q
```

Running these commands from inside this extract alone will fail on the missing
imports listed in Section 4. That is expected.

---

## 6. Claims this code supports

- Production resolver enforces three independent conditions before any model is served.
- Bundle validation refuses a bare estimator of the kind the Stage 3 pipeline itself produces (audit finding C6).
- Regional selections: NSW1/QLD1/VIC1/TAS1 RandomForest_A; SA1/WA RandomForest_B.
- SA1 is correctly resolved to RandomForest_B, has no B bundle yet, and therefore serves A with a visible warning.
- MLP and GRU are recorded NO_MATERIAL_IMPROVEMENT in all six regions and are never servable.

---

## 7. Evidence trail

| Artefact | Where |
|---|---|
| Individual contribution document | `WP4_Ashish_Shrestha.docx` |
| Consolidated work-package report | `PRT661_WP4_Portal_Contribution_and_Progress_Report.docx` |
| Pre-release audit (11 production-correctness findings) | `AUDIT_V3.md` |
| Release change log | `CHANGELOG_V3.md` |
| Test record (go / no-go gates, and what was not run) | `TEST_REPORT_V3.md` |
| Model evidence pack (27 files, SHA-256 manifest) | `data/model_evidence/current/` |
| Running portal | 9 screenshots, 2 October 2026 |
| Commit history | **[INSERT GITHUB COMMIT / PULL REQUEST LINKS]** |

---

*Generated for PRT661 Assessment 2, Group Dan6 / Group 2. Every line count and claim
above is read from the supplied source; none is estimated.*
