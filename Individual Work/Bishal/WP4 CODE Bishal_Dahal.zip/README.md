# PRT661 WP4 — Individual Code Submission

**Bishal Dahal** · S388095 · Model Verification & Dashboard
Work package: WP4 — Operational portal, automation and deployment
Build: portal v3.0.0 · pipeline v4.0.0 · model evidence wp4-2026-09-29
(run `EnergyForecast_Run_20260929_145931`)

---

## 1. Scope of this submission

The four portal views, the accuracy scoring behind them, the generated explanations, accessibility, and the warnings shown when the portal cannot stand behind a number.

This archive contains **only the files owned by this student**, at their original
repository paths. It is an extract from the integrated portal, not a standalone
application: the modules import from teammates' modules that are deliberately not
included here. Section 4 lists those dependencies. The complete runnable system is
the group submission.

> Ownership follows the role titles declared in the portal (`app/app.py`, `TEAM`) and
> the continuity of ownership from WP2 and WP3. It is **not** derived from commit
> history: the supplied repository contained no commits. Commit links must be added
> before submission.

---

## 2. Files owned

| File | Lines | What it does |
|---|---|---|
| `app/app.py` | 4,363 | The Dash application: Dashboard, Forecast Performance, AEMO Comparison and Regional Analysis, with 30 callbacks. Includes the model-comparison view, served-vs-selected labelling, the stale-data guard and the mixed-model-version warning. |
| `app/assets/dashboard.css` | 1,124 | Portal stylesheet. Breakpoints at 1100/900/680/420 px, 44 px touch targets, reduced-motion support, model-family patterns as well as colour. |
| `app/assets/portal_a11y.js` | 83 | Keyboard tab navigation and pane state (Enter/Space/Arrow/Home/End), exposed for testing. |
| `pipeline/insights.py` | 328 | Deterministic generated sentences — no language model. Direction, decision confidence, horizon behaviour, stability by year, weather effect, drivers, peaks and freshness, each with a fixed threshold. |
| `pipeline/verification.py` | 74 | Verification engine. Joins stored forecasts to actual demand on exact timestamps as actuals arrive and upserts error, absolute error, squared error and sMAPE. |
| **Total** | **5,972** | |

---

## 3. Tests owned

| Test file | Covers |
|---|---|
| `tests/test_app_smoke.py` | 16 tests — app import and server start, every callback id exists, all four views render, downloads, provenance labels match served forecasts, stale-data guard, mixed-version warning. |
| `tests/test_evidence_insights.py` | 12 tests — generated wording against the evidence: weak years named, non-monotonic horizons detected, no 'improved' wording when the material-improvement flags are false, manifest OK / missing / tampered. |
| `tests/test_static_assets.py` | 5 tests — responsive breakpoints, 44 px targets, reduced motion. |

---

## 4. Dependencies on other team members

These modules are imported by the files above and are **not** in this archive.

| Member | Module / contract | Why it is needed |
|---|---|---|
| Ashish | — | pipeline/model_evidence.py supplies which model is selected and which is served; the served-vs-selected warning only has meaning because that distinction exists upstream. |
| Sudip | `pipeline/operational_job.py, hourly_job.py` | produce the stored forecasts the verification engine scores. |
| Suraj | `pipeline/timezones.py and database.py` | the market-clock rule is what lets a chart show market time and a clock show local time without either being wrong. |

---

## 5. How to run

From the **complete** project root, with `pip install -r requirements.txt` already done:

```bash
python -m app.app                      # local portal at http://127.0.0.1:8050
python -m pytest tests/test_app_smoke.py tests/test_evidence_insights.py tests/test_static_assets.py -q
```

Running these commands from inside this extract alone will fail on the missing
imports listed in Section 4. That is expected.

---

## 6. Claims this code supports

- Four views, 4,363 lines, 30 callbacks.
- Numeric budget: 3 prominent numbers on Live, 3 on live verification, 2 on AEMO; everything else behind disclosures.
- Five honesty guards: stale data, served vs selected, mixed model version, evidence status, empty states.
- Insight thresholds are asserted in tests, not only in wording — a margin is 'clear' only at >= 3% with DM p < 0.05.
- 3,765 intervals scored across six regions for the September verification window, 0 excluded from sMAPE.

---

## 7. Evidence trail

| Artefact | Where |
|---|---|
| Individual contribution document | `WP4_Bishal_Dahal.docx` |
| Consolidated work-package report | `PRT661_WP4_Portal_Contribution_and_Progress_Report.docx` |
| Pre-release audit (11 production-correctness findings) | `AUDIT_V3.md` |
| Release change log | `CHANGELOG_V3.md` |
| Test record (go / no-go gates, and what was not run) | `TEST_REPORT_V3.md` |
| Model evidence pack (27 files, SHA-256 manifest) | `data/model_evidence/current/` |
| Running portal | 9 screenshots, 2 October 2026 |
| Commit history | **[INSERT GITHUB COMMIT / PULL REQUEST LINKS]** |

---

*Generated for PRT661 Assessment 2, Group Dan6 / Group 2. Every line count and claim
above is read from the supplied source; none is estimated.*
